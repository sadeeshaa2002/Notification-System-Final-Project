<?php
// Include PHPMailer autoload file
require 'phpMailer/PHPMailer.php';
require 'phpMailer/SMTP.php';
require 'phpMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;

// Create a new PHPMailer instance
$mail = new PHPMailer();

// SMTP configuration
$mail->isSMTP();
$mail->Host = 'smtp-relay.brevo.com';  // Your SMTP server
$mail->SMTPAuth = true;
$mail->Username = '74cd97001@smtp-brevo.com'; // SMTP username
$mail->Password = 'xsmtpsib-e36dc6f62ff2b7ed2a8987fea631e1795f7372148f7dfb7191ef7be81899a8cb-L7w9xpfZqN6va8Dm'; // SMTP password
$mail->SMTPSecure = 'tls'; // Enable TLS encryption, ssl also accepted
$mail->Port = 587; // TCP port to connect to

// Sender and recipient
$mail->setFrom('sadeeshaa25@gmail.com', 'Primary Sender');
$mail->addAddress('angika.nimnadi@gmail.com', 'Customer ');

// Email content
$mail->isHTML(true);
$mail->Subject = 'New Contact Form Submission';
$mail->Body = '
    <html>
    <body>
        <h2>New Contact Form Submission : </h2>
        <p>Please use the following detatils to reach out the the sender.</p>
        <h3>Contact Details:</h3>
        <p><strong>Name:</strong> ' . htmlspecialchars($_POST['name']) . '</p>
        <p><strong>Email:</strong> ' . htmlspecialchars($_POST['email']) . '</p>
        <p><strong>Subject:</strong> ' . htmlspecialchars($_POST['subject']) . '</p>
        <p><strong>Message:</strong> ' . nl2br(htmlspecialchars($_POST['message'])) . '</p>
    </body>
    </html>';

// Send email
$response = array();
if ($mail->send()) {
    $response['status'] = 'success';
    $response['message'] = 'Thanks for your message. <br /> I\'ll respond to you shortly';
} else {
    $response['status'] = 'error';
    $response['message'] = 'There was a problem sending your message. Please try again later.';
}

// Send JSON response back to JavaScript
header('Content-Type: application/json');
echo json_encode($response);
?>