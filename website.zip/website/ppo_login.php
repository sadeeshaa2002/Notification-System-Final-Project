<?php
session_start(); // Start the session


$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "shop_dp"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  $email = $_POST['email'];
  $password = $_POST['password'];

 
  $sql = "SELECT * FROM printing_press_operators WHERE email='$email' AND password='$password'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
     
      $user_data = $result->fetch_assoc();
      $_SESSION['user_id'] = $user_data['id']; 
      header("Location: ppo.php");
      exit;
  } else {
      
      $_SESSION['message'] = "Invalid email or password. Please try again.";
  }

  
  header("Location: ".$_SERVER['PHP_SELF']);
  exit;
}


// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <style>
body {
    font-family: "Arial", sans-serif;
    margin: 0;
    padding: 0;
    background-color: #ddd; 
}

.wrapper {
    width: 100%;
    max-width: 450px;
    margin: 100px auto;
    padding: 20px;
    background-color: #fff;
    border: 3px solid #ffb411; 
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
}

.wrapper h1 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 30px;
}

.input-box {
    position: relative;
    margin-bottom: 20px;
}

.input-box input {
    width: 95%;
    padding: 10px;
    border: 1px solid #999; 
    border-radius: 5px;
    outline: none;
}

.input-box i {
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
}

.remember-forgot {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    
}

.remember-forgot label {
    font-size: 14px;

}
.remember-forgot a{
  color: #ffb411;
}

.btn {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #ffb411; 
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    outline: none;
}

.btn:hover {
    background-color: #ffb411;
}

.register-link {
    text-align: center;
}

.register-link a {
    color: #ffb411; 
    text-decoration: none;
}

.message {
    background-color: #fff;
    color: #ffb411;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 4px;
}
      </style>
</head>
<body>
    <div class="wrapper">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
          <h1>Printing Press Operator Login</h1>
               <!-- Display the message if it's set -->
      <?php if(isset($_SESSION['message'])): ?>
      <div class="message"><?php echo $_SESSION['message']; ?></div>
      <?php unset($_SESSION['message']); // Unset the session message after displaying ?>
      <?php endif; ?>

   <!-- Your HTML form here -->
          <div class="input-box">
            <input type="text" name="email" placeholder="Email" required>
            <i class='bx bxs-user'></i>
          </div>
          <div class="input-box">
            <input type="password" name="password" placeholder="Password" required>
            <i class='bx bxs-lock-alt' ></i>
          </div>
          <div class="remember-forgot">
            <label><input type="checkbox">Remember Me</label>
            <a href="#">Forgot Password</a>
          </div>
          <button type="submit" name="login" class="btn">Login</button>
          <div class="register-link">
            <p>Don't have an account? <a href="ppo_register.php">Register</a></p>
          </div>
        </form>
      </div>
</body>
</html>
