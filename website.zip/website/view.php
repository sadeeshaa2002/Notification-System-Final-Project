<?php
@include 'config.php';

// Fetch pending orders for Graphic Designs from notification table
$select_notification = mysqli_query($conn, "SELECT * FROM `notification`");
$graphic_design_orders = [];
if(mysqli_num_rows($select_notification) > 0) {
    while($notification = mysqli_fetch_assoc($select_notification)) {
        $graphic_design_orders[] = $notification;
    }
}

// Fetch pending orders for Printing Press Operator from notification1 table
$select_notification1 = mysqli_query($conn, "SELECT * FROM `notification1`");
$printing_press_orders = [];
if(mysqli_num_rows($select_notification1) > 0) {
    while($notification1 = mysqli_fetch_assoc($select_notification1)) {
        $printing_press_orders[] = $notification1;
    }
}

// Fetch pending orders for Cashiers from notification2 table
$select_notification2 = mysqli_query($conn, "SELECT * FROM `notification2`");
$cashier_orders = [];
if(mysqli_num_rows($select_notification2) > 0) {
    while($notification2 = mysqli_fetch_assoc($select_notification2)) {
        $cashier_orders[] = $notification2;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Pending Orders</title>
   <style>
      body {
         font-family: Arial, sans-serif;
         background-color: #ddd;
         margin: 0;
         padding: 0;
      }

      .container {
         max-width: 1200px;
         margin: 0 auto;
         padding: 20px;
         border-color: #ffb411;
      }

      .order-container {
         background-color: #fff;
         padding: 20px;
         border-radius: 5px;
         box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
         margin-bottom: 20px;
      }

      .order-container h2 {
         font-size: 24px;
         color: #333;
         margin-bottom: 10px;
      }

      .order-item {
         border-bottom: 1px solid #ddd;
         padding: 10px 0;
         margin-bottom: 10px;
      }

      .order-item p {
         margin: 5px 0;
      }

      .empty-message {
         text-align: center;
         color: #999;
         font-style: italic;
      }
   </style>
</head>
<body>

<div class="container">
   <!-- Display Pending Orders for Graphic Designs -->
   <div class="order-container">
      <h2>Graphic Designs - Pending Orders</h2>
      <?php if(empty($graphic_design_orders)): ?>
         <p class="empty-message">No pending orders for Graphic Designs</p>
      <?php else: ?>
         <?php foreach($graphic_design_orders as $order): ?>
            <div class="order-item">
               <p>Name: <?php echo $order['name']; ?></p>
               <p>Price: Rs.<?php echo $order['price']; ?></p>
               <p>Image: <img src="uploaded_img/<?php echo $order['image']; ?>" alt="Product Image" style="max-width: 100px;"></p>
            </div>
         <?php endforeach; ?>
      <?php endif; ?>
   </div>

   <!-- Display Pending Orders for Printing Press Operator -->
   <div class="order-container">
      <h2>Printing Press Operator - Pending Orders</h2>
      <?php if(empty($printing_press_orders)): ?>
         <p class="empty-message">No pending orders for Printing Press Operator</p>
      <?php else: ?>
         <?php foreach($printing_press_orders as $order): ?>
            <div class="order-item">
               <p>Name: <?php echo $order['name']; ?></p>
               <p>Price: Rs.<?php echo $order['price']; ?></p>
               <p>Image: <img src="uploaded_img/<?php echo $order['image']; ?>" alt="Product Image" style="max-width: 100px;"></p>
            </div>
         <?php endforeach; ?>
      <?php endif; ?>
   </div>

   <!-- Display Pending Orders for Cashiers -->
   <div class="order-container">
      <h2>Cashiers - Pending Orders</h2>
      <?php if(empty($cashier_orders)): ?>
         <p class="empty-message">No pending orders for Cashiers</p>
      <?php else: ?>
         <?php foreach($cashier_orders as $order): ?>
            <div class="order-item">
               <p>Name: <?php echo $order['name']; ?></p>
               <p>Price: Rs.<?php echo $order['price']; ?></p>
               <p>Image: <img src="uploaded_img/<?php echo $order['image']; ?>" alt="Product Image" style="max-width: 100px;"></p>
            </div>
         <?php endforeach; ?>
      <?php endif; ?>
   </div>
</div>

</body>
</html>
