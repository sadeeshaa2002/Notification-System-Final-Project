<?php

@include 'config.php';

if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = 1;

   $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name'");

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'product already added to cart';
   }else {
    // Insert the product into the cart table
    $insert_product = mysqli_query($conn, "INSERT INTO `cart` (name, price, image, quantity) VALUES ('$product_name', '$product_price', '$product_image', '$product_quantity')");
    
    // Check if insertion was successful
    if($insert_product) {
        $message[] = 'Product added to cart successfully';
    } else {
        $message[] = 'Failed to add product to cart';
    }
}


}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>products</title>

   
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   
   <style>
 @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
.container{
   max-width: 1200px;
   margin:0 auto;
}

.products .box-container{
   display: grid;
   grid-template-columns: repeat(auto-fit, 18rem);
   gap:1.5rem;
   justify-content: center;
}

.products .box-container .box{
   text-align: center;
   padding: 1rem;
   box-shadow: var(--box-shadow);
   border: 1px solid grey; 
   border-radius: .3rem;
}
.products h1{
    font-size: 35px;
    font-family:'Roboto',sans-serif;
}

.products .box-container .box img{
   height: 10rem;
}

.products .box-container .box h3{
   margin:1rem 0;
   font-size: 30px; 
   color:black;
   font-family:'Roboto',sans-serif;
}

.products .box-container .box .price{
   font-size: 20px;
   color: #bbb lack;;
   font-family:'Roboto',sans-serif;
}
.btn {
         display: inline-block;
         width: 200px;
         padding: 10px;
         border: none;
         border-radius: 4px;
         background-color:#ffb411 ; /* Button color coral */
         color: #fff;
         font-size: 16px;
         cursor: pointer;
         text-align: center;
         font-family:'Roboto',sans-serif;
      }
</style>
</head>
<body>
   
<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   };
};

?>

<?php include 'header.php'; ?>

<div class="container">

<section class="products">

   <h1 class="heading">Latest products</h1>

   <div class="box-container">

      <?php
      
      $select_products = mysqli_query($conn, "SELECT * FROM `products`");
      if(mysqli_num_rows($select_products) > 0){
         while($fetch_product = mysqli_fetch_assoc($select_products)){
      ?>

      <form action="" method="post">
         <div class="box">
            <img src="uploaded_img/<?php echo $fetch_product['image']; ?>" alt="">
            <h3><?php echo $fetch_product['name']; ?></h3>
            <div class="price">Rs.<?php echo $fetch_product['price']; ?></div>
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['image']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
         </div>
      </form>

      <?php
         };
      };
      ?>

   </div>

</section>

</div>


<script src="js/script.js"></script>

</body>
</html>