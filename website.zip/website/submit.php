<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop_dp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if($conn->query($sql) === true){
    echo "Records inserted successfully.";
}
// Escape user inputs for security
$name = $conn->real_escape_string($_POST['yourName']);
$email = $conn->real_escape_string($_POST['emailAddress']);
$subject = $conn->real_escape_string($_POST['subject']);
$message = $conn->real_escape_string($_POST['yourMessage']);

// Attempt insert query execution
$sql = "INSERT INTO contacts (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";
if($conn->query($sql) === true){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . $conn->error;
}

// Close connection
$conn->close();
?>
