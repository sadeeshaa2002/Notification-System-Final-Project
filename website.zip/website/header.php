<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Header with Cart Count</title>

   <style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
.header {
   background-color: #ffb411;
   position: sticky;
   top: 0;
   left: 0;
   z-index: 800;
}

.header .flex {
   display: flex;
   align-items: center; 
   padding: 1rem 1rem;
   max-width: 1400px;
   margin: 0 auto;
}

.header .flex .navbar a {
   font-size: 25px;
   color: white;
   text-decoration: none; 
   font-family:'Roboto',sans-serif;
}

.header .flex .navbar a:hover {
   text-decoration: underline; 
}

.header .flex .cart {
   font-size: 25px;
   color: white;
   margin-left: 1rem; 
   text-decoration: none; 
   font-family:'Roboto',sans-serif;
}

.header .flex .cart:hover {
   text-decoration: underline; 
}



  </style>
</head>
<body>

   <header class="header">
      <div class="flex">
         
         <nav class="navbar">
            <a href="cart.php">View products</a>
         </nav>

         <?php

         $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
         $row_count = mysqli_num_rows($select_rows);
         ?>

         
         <a href="mycart.php" class="cart">My cart</a>
      </div>
   </header>



</body>
</html>
